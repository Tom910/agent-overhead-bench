Independent measurement instrument for short (1–5 minute) selected tasks. Not a capabilities leaderboard, not a vendor harness cost claim.

## Condition: pinned (model: z-ai/glm-5.3-flash; price book: openrouter-2026-09-04; source: agent-overhead-bench / local-development@working-tree; regime: short)

| Harness | vX.Y | Vis. | Source/regime | E2E (med/IQR) | Harness share (full only) | Non-model share (fallback) | Cold start | Parallelism | First byte (med) | Turns | Tokens in/out | Cached % | Cost/task | Cost vs. token floor | Success | Raw |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| claude-code | 2.1.246 (Claude Code) | partial | agent-overhead-bench / local-development@working-tree / short | 29.32s / 10.63s | — | — (non-model 1%) | 371ms | 1.24 | 4.79s | 6.75 | 126345.5/671 | 74% | $0.0040 | 0.4× | 32/32 | [run.json](../results/pinned/claude-code/py-medium-feature-1/rep-0/run.json) |
| cline | 3.0.61 | partial | agent-overhead-bench / local-development@working-tree / short | 44.64s / 11.00s | — | — (non-model 3%) | 702ms | 1.00 | 3.75s | 6 | 40586.75/1123 | 74% | $0.0016 | 0.5× | 32/32 | [run.json](../results/pinned/cline/py-medium-feature-1/rep-0/run.json) |
| codex | codex-cli 0.149.1 | partial | agent-overhead-bench / local-development@working-tree / short | 33.71s / 8.10s | — | — (non-model 16%) | 281ms | 1.00 | 5.25s | 4.5 | 41247.75/403 | 74% | $0.0014 | 0.4× | 32/32 | [run.json](../results/pinned/codex/py-medium-feature-1/rep-0/run.json) |
| hermes | Hermes Agent v0.20.5 (2026.8.19) | partial | agent-overhead-bench / local-development@working-tree / short | 34.04s / 12.04s | — | — (non-model 2%) | 3.00s | 1.00 | 4.47s | 7 | 95119/436.5 | 88% | $0.0024 | 0.3× | 32/32 | [run.json](../results/pinned/hermes/py-medium-feature-1/rep-0/run.json) |
| pi | 0.73.1 | partial | agent-overhead-bench / local-development@working-tree / short | 17.20s / 4.20s | — | — (non-model 1%) | 447ms | 1.00 | 2.22s | 5.5 | 10715.25/322.75 | 91% | $0.0003 | 0.3× | 32/32 | [run.json](../results/pinned/pi/py-medium-feature-1/rep-0/run.json) |
| qwen | 0.22.2 | partial | agent-overhead-bench / local-development@working-tree / short | 32.43s / 13.07s | — | — (non-model 1%) | 943ms | 1.00 | 5.45s | 5 | 114459.75/472.75 | 70% | $0.0034 | 0.4× | 32/32 | [run.json](../results/pinned/qwen/py-medium-feature-1/rep-0/run.json) |

### Per-task drill-down

| Harness | Task | Vis. | E2E (med/IQR) | Model (med) | Parallelism | First byte (med) | Non-model (med) | Harness share (full only) | Cost/task | Success | Raw |
|---|---|---|---|---|---|---|---|---|---|---|---|
| claude-code | py-medium-feature-1 | partial | 33.61s / 17.70s | 32.82s | 1.14 | 4.91s | 358ms | — | $0.0040 | 4/4 | [run.json](../results/pinned/claude-code/py-medium-feature-1/rep-0/run.json) |
| claude-code | py-medium-refactor-1 | partial | 28.01s / 6.65s | 27.35s | 1.26 | 4.66s | 255ms | — | $0.0040 | 4/4 | [run.json](../results/pinned/claude-code/py-medium-refactor-1/rep-0/run.json) |
| claude-code | py-small-bugfix-1 | partial | 34.95s / 9.27s | 34.22s | 1.20 | 4.91s | 311ms | — | $0.0058 | 4/4 | [run.json](../results/pinned/claude-code/py-small-bugfix-1/rep-0/run.json) |
| claude-code | py-small-testfix-1 | partial | 31.90s / 15.85s | 31.17s | 1.15 | 4.68s | 323ms | — | $0.0037 | 4/4 | [run.json](../results/pinned/claude-code/py-small-testfix-1/rep-0/run.json) |
| claude-code | ts-medium-feature-1 | partial | 28.12s / 11.02s | 27.54s | 1.41 | 4.15s | 283ms | — | $0.0050 | 4/4 | [run.json](../results/pinned/claude-code/ts-medium-feature-1/rep-0/run.json) |
| claude-code | ts-medium-refactor-1 | partial | 30.51s / 3.76s | 29.87s | 1.46 | 5.10s | 236ms | — | $0.0041 | 4/4 | [run.json](../results/pinned/claude-code/ts-medium-refactor-1/rep-0/run.json) |
| claude-code | ts-small-bugfix-1 | partial | 19.58s / 16.16s | 18.98s | 1.22 | 2.95s | 283ms | — | $0.0038 | 4/4 | [run.json](../results/pinned/claude-code/ts-small-bugfix-1/rep-0/run.json) |
| claude-code | ts-small-testfix-1 | partial | 24.61s / 10.25s | 24.06s | 1.33 | 4.95s | 228ms | — | $0.0033 | 4/4 | [run.json](../results/pinned/claude-code/ts-small-testfix-1/rep-0/run.json) |
| cline | py-medium-feature-1 | partial | 48.44s / 9.32s | 46.13s | 1.00 | 1.49s | 1.56s | — | $0.0016 | 4/4 | [run.json](../results/pinned/cline/py-medium-feature-1/rep-0/run.json) |
| cline | py-medium-refactor-1 | partial | 47.06s / 12.72s | 44.95s | 1.00 | 1.54s | 1.49s | — | $0.0017 | 4/4 | [run.json](../results/pinned/cline/py-medium-refactor-1/rep-0/run.json) |
| cline | py-small-bugfix-1 | partial | 42.23s / 15.21s | 40.04s | 1.00 | 4.87s | 1.47s | — | $0.0012 | 4/4 | [run.json](../results/pinned/cline/py-small-bugfix-1/rep-0/run.json) |
| cline | py-small-testfix-1 | partial | 38.19s / 8.22s | 36.02s | 1.00 | 4.88s | 1.60s | — | $0.0012 | 4/4 | [run.json](../results/pinned/cline/py-small-testfix-1/rep-0/run.json) |
| cline | ts-medium-feature-1 | partial | 61.90s / 12.68s | 59.28s | 1.00 | 3.54s | 1.48s | — | $0.0020 | 4/4 | [run.json](../results/pinned/cline/ts-medium-feature-1/rep-0/run.json) |
| cline | ts-medium-refactor-1 | partial | 51.52s / 14.86s | 48.70s | 1.00 | 3.97s | 1.44s | — | $0.0017 | 4/4 | [run.json](../results/pinned/cline/ts-medium-refactor-1/rep-0/run.json) |
| cline | ts-small-bugfix-1 | partial | 30.73s / 4.34s | 28.42s | 1.00 | 4.02s | 1.54s | — | $0.0008 | 4/4 | [run.json](../results/pinned/cline/ts-small-bugfix-1/rep-0/run.json) |
| cline | ts-small-testfix-1 | partial | 41.19s / 5.66s | 39.09s | 1.00 | 2.69s | 1.43s | — | $0.0016 | 4/4 | [run.json](../results/pinned/cline/ts-small-testfix-1/rep-0/run.json) |
| codex | py-medium-feature-1 | partial | 32.11s / 2.99s | 26.41s | 1.00 | 5.27s | 5.43s | — | $0.0014 | 4/4 | [run.json](../results/pinned/codex/py-medium-feature-1/rep-0/run.json) |
| codex | py-medium-refactor-1 | partial | 35.51s / 9.75s | 29.79s | 1.00 | 5.19s | 5.45s | — | $0.0014 | 4/4 | [run.json](../results/pinned/codex/py-medium-refactor-1/rep-0/run.json) |
| codex | py-small-bugfix-1 | partial | 35.18s / 7.74s | 29.44s | 1.00 | 5.22s | 5.45s | — | $0.0013 | 4/4 | [run.json](../results/pinned/codex/py-small-bugfix-1/rep-0/run.json) |
| codex | py-small-testfix-1 | partial | 48.34s / 11.30s | 42.51s | 1.00 | 4.91s | 5.48s | — | $0.0018 | 4/4 | [run.json](../results/pinned/codex/py-small-testfix-1/rep-0/run.json) |
| codex | ts-medium-feature-1 | partial | 33.05s / 12.39s | 27.46s | 1.00 | 6.32s | 5.31s | — | $0.0014 | 4/4 | [run.json](../results/pinned/codex/ts-medium-feature-1/rep-0/run.json) |
| codex | ts-medium-refactor-1 | partial | 34.38s / 7.68s | 28.68s | 1.00 | 5.68s | 5.41s | — | $0.0013 | 4/4 | [run.json](../results/pinned/codex/ts-medium-refactor-1/rep-0/run.json) |
| codex | ts-small-bugfix-1 | partial | 25.95s / 8.14s | 20.29s | 1.00 | 5.16s | 5.40s | — | $0.0012 | 4/4 | [run.json](../results/pinned/codex/ts-small-bugfix-1/rep-0/run.json) |
| codex | ts-small-testfix-1 | partial | 28.37s / 8.05s | 22.68s | 1.00 | 5.62s | 5.39s | — | $0.0012 | 4/4 | [run.json](../results/pinned/codex/ts-small-testfix-1/rep-0/run.json) |
| hermes | py-medium-feature-1 | partial | 41.59s / 5.92s | 36.90s | 1.00 | 4.69s | 729ms | — | $0.0025 | 4/4 | [run.json](../results/pinned/hermes/py-medium-feature-1/rep-0/run.json) |
| hermes | py-medium-refactor-1 | partial | 37.96s / 1.57s | 33.21s | 1.00 | 5.30s | 730ms | — | $0.0017 | 4/4 | [run.json](../results/pinned/hermes/py-medium-refactor-1/rep-0/run.json) |
| hermes | py-small-bugfix-1 | partial | 32.47s / 4.21s | 28.79s | 1.00 | 4.19s | 660ms | — | $0.0023 | 4/4 | [run.json](../results/pinned/hermes/py-small-bugfix-1/rep-0/run.json) |
| hermes | py-small-testfix-1 | partial | 25.07s / 18.34s | 21.04s | 1.00 | 2.88s | 760ms | — | $0.0025 | 4/4 | [run.json](../results/pinned/hermes/py-small-testfix-1/rep-0/run.json) |
| hermes | ts-medium-feature-1 | partial | 47.70s / 29.19s | 43.69s | 1.00 | 5.10s | 792ms | — | $0.0025 | 4/4 | [run.json](../results/pinned/hermes/ts-medium-feature-1/rep-0/run.json) |
| hermes | ts-medium-refactor-1 | partial | 35.61s / 18.16s | 32.14s | 1.00 | 4.53s | 732ms | — | $0.0022 | 4/4 | [run.json](../results/pinned/hermes/ts-medium-refactor-1/rep-0/run.json) |
| hermes | ts-small-bugfix-1 | partial | 30.80s / 5.39s | 26.98s | 1.00 | 4.41s | 746ms | — | $0.0020 | 4/4 | [run.json](../results/pinned/hermes/ts-small-bugfix-1/rep-0/run.json) |
| hermes | ts-small-testfix-1 | partial | 27.97s / 24.12s | 24.38s | 1.00 | 4.41s | 686ms | — | $0.0025 | 4/4 | [run.json](../results/pinned/hermes/ts-small-testfix-1/rep-0/run.json) |
| pi | py-medium-feature-1 | partial | 17.47s / 5.87s | 16.69s | 1.00 | 2.34s | 291ms | — | $0.0003 | 4/4 | [run.json](../results/pinned/pi/py-medium-feature-1/rep-0/run.json) |
| pi | py-medium-refactor-1 | partial | 17.97s / 4.71s | 17.21s | 1.00 | 2.09s | 286ms | — | $0.0005 | 4/4 | [run.json](../results/pinned/pi/py-medium-refactor-1/rep-0/run.json) |
| pi | py-small-bugfix-1 | partial | 18.04s / 3.69s | 17.32s | 1.00 | 2.45s | 285ms | — | $0.0003 | 4/4 | [run.json](../results/pinned/pi/py-small-bugfix-1/rep-0/run.json) |
| pi | py-small-testfix-1 | partial | 16.94s / 1.43s | 16.23s | 1.00 | 1.84s | 272ms | — | $0.0002 | 4/4 | [run.json](../results/pinned/pi/py-small-testfix-1/rep-0/run.json) |
| pi | ts-medium-feature-1 | partial | 29.34s / 6.70s | 28.64s | 1.00 | 2.48s | 242ms | — | $0.0006 | 4/4 | [run.json](../results/pinned/pi/ts-medium-feature-1/rep-0/run.json) |
| pi | ts-medium-refactor-1 | partial | 15.12s / 7.76s | 14.46s | 1.00 | 2.61s | 228ms | — | $0.0004 | 4/4 | [run.json](../results/pinned/pi/ts-medium-refactor-1/rep-0/run.json) |
| pi | ts-small-bugfix-1 | partial | 11.72s / 2.64s | 11.04s | 1.00 | 1.95s | 235ms | — | $0.0002 | 4/4 | [run.json](../results/pinned/pi/ts-small-bugfix-1/rep-0/run.json) |
| pi | ts-small-testfix-1 | partial | 9.73s / 1.50s | 9.03s | 1.00 | 1.76s | 240ms | — | $0.0002 | 4/4 | [run.json](../results/pinned/pi/ts-small-testfix-1/rep-0/run.json) |
| qwen | py-medium-feature-1 | partial | 35.89s / 15.53s | 34.39s | 1.00 | 4.79s | 523ms | — | $0.0047 | 4/4 | [run.json](../results/pinned/qwen/py-medium-feature-1/rep-0/run.json) |
| qwen | py-medium-refactor-1 | partial | 49.55s / 23.04s | 48.07s | 1.00 | 5.65s | 530ms | — | $0.0055 | 4/4 | [run.json](../results/pinned/qwen/py-medium-refactor-1/rep-0/run.json) |
| qwen | py-small-bugfix-1 | partial | 28.97s / 12.72s | 27.57s | 1.00 | 4.96s | 465ms | — | $0.0028 | 4/4 | [run.json](../results/pinned/qwen/py-small-bugfix-1/rep-0/run.json) |
| qwen | py-small-testfix-1 | partial | 28.69s / 2.50s | 27.23s | 1.00 | 5.05s | 492ms | — | $0.0031 | 4/4 | [run.json](../results/pinned/qwen/py-small-testfix-1/rep-0/run.json) |
| qwen | ts-medium-feature-1 | partial | 38.53s / 3.99s | 37.08s | 1.00 | 5.57s | 495ms | — | $0.0033 | 4/4 | [run.json](../results/pinned/qwen/ts-medium-feature-1/rep-0/run.json) |
| qwen | ts-medium-refactor-1 | partial | 43.06s / 13.42s | 41.65s | 1.00 | 5.89s | 465ms | — | $0.0047 | 4/4 | [run.json](../results/pinned/qwen/ts-medium-refactor-1/rep-0/run.json) |
| qwen | ts-small-bugfix-1 | partial | 26.30s / 15.75s | 24.89s | 1.00 | 5.37s | 452ms | — | $0.0034 | 4/4 | [run.json](../results/pinned/qwen/ts-small-bugfix-1/rep-0/run.json) |
| qwen | ts-small-testfix-1 | partial | 27.78s / 8.72s | 26.43s | 1.00 | 5.54s | 432ms | — | $0.0032 | 4/4 | [run.json](../results/pinned/qwen/ts-small-testfix-1/rep-0/run.json) |

## Review appendix

- `pinned:hermes:ts-small-testfix-1:0`: end-to-end 98274.27899999986ms exceeds 3× cell median 27974.205250000115ms
- `pinned:qwen:ts-small-bugfix-1:3`: end-to-end 79193.83408299927ms exceeds 3× cell median 26300.97256299993ms